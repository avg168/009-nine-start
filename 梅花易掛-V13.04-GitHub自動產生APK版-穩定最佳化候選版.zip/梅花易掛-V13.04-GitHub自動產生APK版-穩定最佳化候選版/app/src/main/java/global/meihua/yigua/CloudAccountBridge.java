package global.meihua.yigua;

import android.webkit.JavascriptInterface;

/**
 * Exposes cloud-readiness state to the trusted bundled WebView.
 * This does NOT fake a cloud login. A real backend and authenticated member session are required.
 */
public final class CloudAccountBridge {
    @JavascriptInterface
    public boolean isCloudConfigured() {
        return ServerConfig.isConfigured();
    }

    @JavascriptInterface
    public String getMode() {
        return ServerConfig.isConfigured() ? "cloud" : "local-test";
    }
}
