package global.meihua.yigua;

/**
 * V13.011 secure backend configuration.
 *
 * IMPORTANT:
 * - Leave BASE_URL empty until a real HTTPS backend is deployed.
 * - Do not embed service-account private keys or Google Play API credentials in the APK.
 * - In production, authenticate API calls with a real member/session token.
 */
public final class ServerConfig {
    private ServerConfig() {}

    public static final String BASE_URL = "";
    // OAuth 2.0 Web application client ID used as the Google ID-token audience.
    public static final String GOOGLE_WEB_CLIENT_ID = "";
    public static final boolean CLOUD_POINTS_REQUIRED_FOR_PRODUCTION = true;

    public static boolean isGoogleSignInConfigured() {
        return isConfigured() && GOOGLE_WEB_CLIENT_ID != null &&
                GOOGLE_WEB_CLIENT_ID.endsWith(".apps.googleusercontent.com");
    }

    public static boolean isConfigured() {
        return BASE_URL != null && BASE_URL.startsWith("https://") && BASE_URL.length() > 12;
    }
}
