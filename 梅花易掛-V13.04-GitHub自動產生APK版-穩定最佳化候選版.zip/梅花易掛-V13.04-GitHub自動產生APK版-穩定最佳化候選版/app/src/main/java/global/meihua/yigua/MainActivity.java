package global.meihua.yigua;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final String HOME_URL = "file:///android_asset/index.html";
    private WebView webView;
    private BillingManager billingManager;
    private CloudApiBridge cloudApiBridge;
    private GoogleSignInBridge googleSignInBridge;

    private void runWebAudits() {
        if (webView == null) return;
        webView.evaluateJavascript(
            "try{" +
            "if(window.MHFunctionAudit)MHFunctionAudit();" +
            "if(window.MHProductionAudit)MHProductionAudit();" +
            "if(window.MHReleaseAudit)MHReleaseAudit();" +
            "}catch(e){console.warn(e);}",
            null
        );
    }

    private void rebuildWebViewAfterRendererLoss() {
        runOnUiThread(() -> {
            try {
                if (webView != null) {
                    webView.removeJavascriptInterface("AndroidPoints");
                    webView.removeJavascriptInterface("AndroidBridge");
                    webView.removeJavascriptInterface("AndroidClipboard");
                    webView.removeJavascriptInterface("CloudAccount");
                    webView.removeJavascriptInterface("CloudApi");
                    webView.removeJavascriptInterface("GoogleSignInNative");
                    webView.removeJavascriptInterface("AndroidBilling");
                    webView.destroy();
                }
            } catch (Exception ignored) {}
            webView = null;
            recreate();
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            s.setAllowFileAccessFromFileURLs(false);
            s.setAllowUniversalAccessFromFileURLs(false);
        }

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new SafeWebViewClient());

        // Bridges are exposed only to the bundled trusted asset page.
        webView.addJavascriptInterface(new AndroidPointsBridge(this), "AndroidPoints");
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        webView.addJavascriptInterface(new AndroidClipboardBridge(this), "AndroidClipboard");
        webView.addJavascriptInterface(new CloudAccountBridge(), "CloudAccount");
        cloudApiBridge = new CloudApiBridge(this, webView);
        webView.addJavascriptInterface(cloudApiBridge, "CloudApi");
        googleSignInBridge = new GoogleSignInBridge(this, webView, cloudApiBridge);
        webView.addJavascriptInterface(googleSignInBridge, "GoogleSignInNative");
        billingManager = new BillingManager(this, webView);
        webView.addJavascriptInterface(billingManager, "AndroidBilling");

        boolean restored = false;
        if (savedInstanceState != null) {
            try {
                restored = webView.restoreState(savedInstanceState) != null;
            } catch (Exception ignored) {
                restored = false;
            }
        }
        if (!restored) webView.loadUrl(HOME_URL);
    }

    private class SafeWebViewClient extends WebViewClient {
        private boolean handleUri(Uri uri) {
            if (uri == null) return false;
            String scheme = uri.getScheme();
            String url = uri.toString();

            if ("file".equalsIgnoreCase(scheme) && url.startsWith("file:///android_asset/")) {
                return false;
            }

            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            } catch (Exception ignored) {
            }
            return true;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUri(request == null ? null : request.getUrl());
        }

        @Override
        @SuppressWarnings("deprecation")
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            try {
                return handleUri(Uri.parse(url));
            } catch (Exception e) {
                return true;
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (url != null && url.startsWith("file:///android_asset/")) {
                runWebAudits();
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            // Android 8.0+ renderer termination handling: rebuild instead of leaving a white screen.
            rebuildWebViewAfterRendererLoss();
            return true;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) {
            try { webView.saveState(outState); } catch (Exception ignored) {}
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (billingManager != null) billingManager.onResume();
        if (webView != null) {
            webView.onResume();
            runWebAudits();
            webView.evaluateJavascript("try{window.dispatchEvent(new Event('pageshow'));}catch(e){console.warn(e);}", null);
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        webView.evaluateJavascript(
            "(function(){try{return !!(window.mhHandleUiBack&&window.mhHandleUiBack());}catch(e){return false;}})();",
            value -> {
                if ("true".equals(value)) return;
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    MainActivity.super.onBackPressed();
                }
            }
        );
    }

    @Override
    protected void onDestroy() {
        if (cloudApiBridge != null) { cloudApiBridge.destroy(); }

        if (webView != null) {
            try {
                webView.loadUrl("about:blank");
                webView.stopLoading();
                webView.removeJavascriptInterface("AndroidPoints");
                webView.removeJavascriptInterface("AndroidBridge");
                webView.removeJavascriptInterface("AndroidClipboard");
                webView.removeJavascriptInterface("CloudAccount");
                webView.removeJavascriptInterface("CloudApi");
                webView.removeJavascriptInterface("GoogleSignInNative");
                webView.removeJavascriptInterface("AndroidBilling");
                webView.clearHistory();
                webView.removeAllViews();
                webView.destroy();
            } catch (Exception ignored) {}
            webView = null;
        }
        if (billingManager != null) {
            try { billingManager.destroy(); } catch (Exception ignored) {}
            billingManager = null;
        }
        cloudApiBridge = null;
        googleSignInBridge = null;
        super.onDestroy();
    }

    public static class AndroidPointsBridge {
        private static final String PREF = "meihua_points_prefs";
        private static final String KEY_POINTS = "points";
        private final SharedPreferences prefs;

        private static final String KEY_V1303_TEST_GRANT = "v13_03_test_points_granted";
        private static final int V1303_TEST_POINTS = 100;

        AndroidPointsBridge(Context context) {
            prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);

            // V13.03 functional-test build: grant a one-time test balance.
            // Existing balances above 100 are never reduced or overwritten.
            if (!prefs.getBoolean(KEY_V1303_TEST_GRANT, false)) {
                int current = Math.max(0, prefs.getInt(KEY_POINTS, 0));
                int target = Math.max(current, V1303_TEST_POINTS);
                prefs.edit()
                        .putInt(KEY_POINTS, target)
                        .putBoolean(KEY_V1303_TEST_GRANT, true)
                        .commit();
            }
        }

        @JavascriptInterface
        public int getPoints() {
            return Math.max(0, prefs.getInt(KEY_POINTS, 0));
        }

        @JavascriptInterface
        public boolean setPoints(int points) {
            int safe = Math.max(0, points);
            return prefs.edit().putInt(KEY_POINTS, safe).commit();
        }
    }

    public static class AndroidClipboardBridge {
        private final Context context;

        AndroidClipboardBridge(Context context) {
            this.context = context.getApplicationContext();
        }

        @JavascriptInterface
        public boolean copyText(String text) {
            try {
                ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null) return false;
                cm.setPrimaryClip(ClipData.newPlainText("梅花易掛", text == null ? "" : text));
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    public class AndroidBridge {
        private final Context context;

        AndroidBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public String getAppVersion() {
            return "13.04";
        }

        @JavascriptInterface
        public String getPlatform() {
            return "android";
        }

        @JavascriptInterface
        public String ping() {
            return "ok";
        }

        @JavascriptInterface
        public void shareText(String subject, String text) {
            final String safeSubject = subject == null ? "梅花易掛" : subject;
            final String safeText = text == null ? "" : text;
            runOnUiThread(() -> {
                try {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, safeSubject);
                    send.putExtra(Intent.EXTRA_TEXT, safeText);
                    startActivity(Intent.createChooser(send, "分享梅花易掛結果"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "此裝置目前無法分享", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void printPage(String jobName) {
            final String safeJobName = (jobName == null || jobName.trim().isEmpty()) ? "梅花易掛" : jobName.trim();
            runOnUiThread(() -> {
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    if (printManager == null || webView == null) {
                        Toast.makeText(MainActivity.this, "此裝置目前無法列印", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(safeJobName);
                    printManager.print(safeJobName, adapter, null);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "列印功能啟動失敗", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public boolean saveTextFile(String filename, String text) {
            String safeName = sanitizeFileName(filename);
            byte[] data = (text == null ? "" : text).getBytes(StandardCharsets.UTF_8);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/梅花易掛");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    boolean completed = false;
                    try {
                        try (OutputStream os = getContentResolver().openOutputStream(uri, "w")) {
                            if (os == null) return false;
                            os.write(data);
                            os.flush();
                        }
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                        getContentResolver().update(uri, done, null, null);
                        completed = true;
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "已儲存到 Downloads/梅花易掛", Toast.LENGTH_SHORT).show());
                        return true;
                    } finally {
                        if (!completed) {
                            try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) {}
                        }
                    }
                }

                // Android 8–9: no storage permission is needed for the app-specific Downloads directory.
                File base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (base == null) base = getFilesDir();
                File dir = new File(base, "梅花易掛");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File file = new File(dir, safeName);
                try (FileOutputStream fos = new FileOutputStream(file, false)) {
                    fos.write(data);
                    fos.flush();
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "檔案已儲存", Toast.LENGTH_SHORT).show());
                return true;
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "檔案儲存失敗", Toast.LENGTH_SHORT).show());
                return false;
            }
        }

        private String sanitizeFileName(String name) {
            String n = (name == null || name.trim().isEmpty()) ? "梅花易掛.txt" : name.trim();
            n = n.replaceAll("[\\\\/:*?\"<>|\\r\\n]+", "_");
            if (!n.toLowerCase().endsWith(".txt")) n += ".txt";
            if (n.length() > 80) n = n.substring(0, 76) + ".txt";
            return n;
        }
    }
}
