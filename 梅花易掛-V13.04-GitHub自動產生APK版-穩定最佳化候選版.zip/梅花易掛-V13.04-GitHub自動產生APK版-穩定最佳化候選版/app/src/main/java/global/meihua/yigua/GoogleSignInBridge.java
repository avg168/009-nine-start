package global.meihua.yigua;

import android.app.Activity;
import android.os.CancellationSignal;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import org.json.JSONObject;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public final class GoogleSignInBridge {
    private final Activity activity;
    private final WebView webView;
    private final CloudApiBridge cloudApi;
    private final CredentialManager credentialManager;
    private final Executor executor = Executors.newSingleThreadExecutor();

    public GoogleSignInBridge(Activity activity, WebView webView, CloudApiBridge cloudApi) {
        this.activity = activity;
        this.webView = webView;
        this.cloudApi = cloudApi;
        this.credentialManager = CredentialManager.create(activity);
    }

    @JavascriptInterface
    public boolean isConfigured() {
        return ServerConfig.isGoogleSignInConfigured();
    }

    @JavascriptInterface
    public void signIn() {
        if (!ServerConfig.isGoogleSignInConfigured()) {
            callback("google_not_configured", false, "{}");
            return;
        }
        requestGoogleCredential(true);
    }

    private void requestGoogleCredential(boolean authorizedOnly) {
        final String nonce = secureNonce();
        final GetGoogleIdOption option = new GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(authorizedOnly)
                .setServerClientId(ServerConfig.GOOGLE_WEB_CLIENT_ID)
                .setAutoSelectEnabled(authorizedOnly)
                .setNonce(nonce)
                .build();

        final GetCredentialRequest request = new GetCredentialRequest.Builder()
                .addCredentialOption(option)
                .build();

        credentialManager.getCredentialAsync(
                activity,
                request,
                new CancellationSignal(),
                executor,
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(GetCredentialResponse result) {
                        try {
                            Credential credential = result.getCredential();
                            if (!(credential instanceof CustomCredential)) {
                                callback("google_wrong_credential", false, "{}");
                                return;
                            }
                            CustomCredential custom = (CustomCredential) credential;
                            if (!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                                    .equals(custom.getType())) {
                                callback("google_wrong_credential", false, "{}");
                                return;
                            }

                            GoogleIdTokenCredential googleCredential =
                                    GoogleIdTokenCredential.createFrom(custom.getData());

                            String idToken = googleCredential.getIdToken();
                            if (idToken == null || idToken.isEmpty()) {
                                callback("google_missing_token", false, "{}");
                                return;
                            }

                            // Security boundary: token goes directly native -> backend.
                            // Do not persist it and do not expose it to JavaScript.
                            cloudApi.loginWithGoogleIdTokenInternal(idToken);
                            callback("google_token_sent", true, "{}");
                        } catch (Exception e) {
                            callback("google_parse_error", false,
                                    "{\"error\":" + JSONObject.quote(e.getClass().getSimpleName()) + "}");
                        }
                    }

                    @Override
                    public void onError(@NonNull GetCredentialException e) {
                        if (authorizedOnly) {
                            // If no previously-authorized account succeeds, allow all accounts.
                            requestGoogleCredential(false);
                        } else {
                            callback("google_signin_failed", false,
                                    "{\"error\":" + JSONObject.quote(e.getClass().getSimpleName()) + "}");
                        }
                    }
                }
        );
    }

    private String secureNonce() {
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private void callback(String event, boolean ok, String payload) {
        activity.runOnUiThread(() -> {
            if (webView == null) return;
            String json = (payload == null || payload.isEmpty()) ? "{}" : payload;
            String js = "try{if(window.onGoogleNativeEvent)window.onGoogleNativeEvent(" +
                    JSONObject.quote(event) + "," + (ok ? "true" : "false") + "," +
                    json + ");}catch(e){console.warn(e);}";
            webView.evaluateJavascript(js, null);
        });
    }
}
