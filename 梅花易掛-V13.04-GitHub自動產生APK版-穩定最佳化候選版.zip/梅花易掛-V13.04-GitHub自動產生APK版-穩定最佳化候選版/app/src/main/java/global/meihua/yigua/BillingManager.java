package global.meihua.yigua;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryProductDetailsResult;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * V12.87 Google Play Billing bridge.
 * Products are consumable one-time products. Entitlement is granted only for PURCHASED state.
 * A local purchase-token ledger prevents duplicate point grants if consumption must be retried.
 *
 * For stronger fraud protection in production at scale, verify purchase tokens on a secure backend.
 */
public class BillingManager implements PurchasesUpdatedListener {
    private static final String POINT_PREF = "meihua_points_prefs";
    private static final String POINT_KEY = "points";
    private static final String BILLING_PREF = "meihua_billing_prefs";
    private static final String GRANTED_TOKENS = "granted_tokens";

    private final Activity activity;
    private final WebView webView;
    private final BillingClient billingClient;
    private final SharedPreferences pointPrefs;
    private final SharedPreferences billingPrefs;
    private final Map<String,Integer> productPoints = new HashMap<>();

    public BillingManager(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        this.pointPrefs = activity.getSharedPreferences(POINT_PREF, Context.MODE_PRIVATE);
        this.billingPrefs = activity.getSharedPreferences(BILLING_PREF, Context.MODE_PRIVATE);

        productPoints.put("points_100", 100);
        productPoints.put("points_400", 400);
        productPoints.put("points_800", 800);
        productPoints.put("points_2000", 2000);
        productPoints.put("points_4500", 4500);
        productPoints.put("points_7000", 7000);

        billingClient = BillingClient.newBuilder(activity)
                .setListener(this)
                .enablePendingPurchases(
                        PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();

        start();
    }

    private void start() {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    notifyJs("ready", "", 0, "Google Play Billing ready");
                    queryUnfinishedPurchases();
                } else {
                    notifyJs("error", "", 0, result.getDebugMessage());
                }
            }
            @Override public void onBillingServiceDisconnected() {
                // Auto reconnection is enabled in Billing Library 9.1.0.
            }
        });
    }

    @JavascriptInterface
    public boolean isReady() {
        return billingClient.isReady();
    }

    @JavascriptInterface
    public boolean isCloudModeConfigured() {
        return ServerConfig.isConfigured();
    }

    @JavascriptInterface
    public void purchase(String productId) {
        if (!productPoints.containsKey(productId)) {
            notifyJs("error", productId, 0, "Unknown product");
            return;
        }
        activity.runOnUiThread(() -> queryAndLaunch(productId));
    }

    private void queryAndLaunch(String productId) {
        List<QueryProductDetailsParams.Product> products = new ArrayList<>();
        products.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.INAPP)
                .build());

        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(products)
                .build();

        billingClient.queryProductDetailsAsync(params, (result, detailsResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                notifyJs("error", productId, 0, result.getDebugMessage());
                return;
            }

            List<ProductDetails> list = detailsResult.getProductDetailsList();
            if (list == null || list.isEmpty()) {
                notifyJs("error", productId, 0,
                        "Product unavailable. Check Play Console product activation and tester account.");
                return;
            }

            ProductDetails details = list.get(0);
            String offerToken = null;

            List<ProductDetails.OneTimePurchaseOfferDetails> offers =
                    details.getOneTimePurchaseOfferDetailsList();
            if (offers != null && !offers.isEmpty()) {
                offerToken = offers.get(0).getOfferToken();
            } else if (details.getOneTimePurchaseOfferDetails() != null) {
                offerToken = details.getOneTimePurchaseOfferDetails().getOfferToken();
            }

            if (offerToken == null || offerToken.isEmpty()) {
                notifyJs("error", productId, 0, "No eligible Google Play offer.");
                return;
            }

            BillingFlowParams.ProductDetailsParams pdp =
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                            .setProductDetails(details)
                            .setOfferToken(offerToken)
                            .build();

            List<BillingFlowParams.ProductDetailsParams> pdps = new ArrayList<>();
            pdps.add(pdp);

            BillingFlowParams flow = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(pdps)
                    .build();

            BillingResult launch = billingClient.launchBillingFlow(activity, flow);
            if (launch.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                notifyJs("error", productId, 0, launch.getDebugMessage());
            }
        });
    }

    @Override
    public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        int code = result.getResponseCode();
        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase p : purchases) processPurchase(p);
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            notifyJs("cancelled", "", 0, "Purchase cancelled");
        } else {
            notifyJs("error", "", 0, result.getDebugMessage());
        }
    }

    public void onResume() {
        if (billingClient.isReady()) queryUnfinishedPurchases();
    }

    private void queryUnfinishedPurchases() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP)
                .build();

        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                for (Purchase p : purchases) processPurchase(p);
            }
        });
    }

    private void processPurchase(Purchase purchase) {
        if (purchase.getPurchaseState() == Purchase.PurchaseState.PENDING) {
            String id = purchase.getProducts().isEmpty() ? "" : purchase.getProducts().get(0);
            notifyJs("pending", id, 0, "Payment pending");
            return;
        }
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;

        String token = purchase.getPurchaseToken();
        List<String> products = purchase.getProducts();
        if (products == null || products.isEmpty()) return;

        String productId = products.get(0);
        Integer unitPoints = productPoints.get(productId);
        if (unitPoints == null) return;

        int quantity = Math.max(1, purchase.getQuantity());
        int pointsToGrant = unitPoints * quantity;

        Set<String> granted = new HashSet<>(
                billingPrefs.getStringSet(GRANTED_TOKENS, new HashSet<>()));
        boolean alreadyGranted = granted.contains(token);

        /*
         * V12.93 CLOUD SERVER-AUTHORITY POINT:
         * When ServerConfig is configured, production should POST the purchaseToken,
         * productId, quantity and authenticated member identity to the secure backend.
         * The backend must verify with Google Play Developer API and return the new
         * authoritative cloud balance. Until then, the code below remains LOCAL-TEST
         * entitlement logic for Internal Testing only.
         */
        
        if (ServerConfig.isConfigured()) {
            // V12.93: Production cloud mode must verify purchaseToken on the backend.
            // Local point grant is intentionally blocked here.
            notifyJs("server_verification_required", productId, 0, purchase.getPurchaseToken());
            return;
        }

        if (!alreadyGranted) {
            int before = Math.max(0, pointPrefs.getInt(POINT_KEY, 0));
            long targetLong = (long) before + pointsToGrant;
            int target = targetLong > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) targetLong;

            boolean pointSaved = pointPrefs.edit().putInt(POINT_KEY, target).commit();
            if (!pointSaved) {
                notifyJs("error", productId, 0, "Unable to save points; purchase not consumed.");
                return;
            }

            granted.add(token);
            boolean tokenSaved = billingPrefs.edit().putStringSet(
                    GRANTED_TOKENS, new HashSet<>(granted)).commit();

            if (!tokenSaved) {
                // Roll back points if the dedupe token cannot be persisted.
                pointPrefs.edit().putInt(POINT_KEY, before).commit();
                notifyJs("error", productId, 0, "Unable to secure purchase token; points rolled back.");
                return;
            }

            notifyJs("granted", productId, pointsToGrant, "Points added");
        }

        ConsumeParams consume = ConsumeParams.newBuilder()
                .setPurchaseToken(token)
                .build();
        billingClient.consumeAsync(consume, (consumeResult, purchaseToken) -> {
            if (consumeResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                notifyJs("consumed", productId, 0, "Purchase completed");
            } else {
                // Token remains in the ledger. A later query can retry consumption without re-granting.
                notifyJs("consume_retry", productId, 0, consumeResult.getDebugMessage());
            }
        });
    }

    private void notifyJs(String event, String productId, int points, String message) {
        activity.runOnUiThread(() -> {
            if (webView == null) return;
            String js = "try{if(window.onPlayBillingEvent)window.onPlayBillingEvent(" +
                    JSONObject.quote(event) + "," +
                    JSONObject.quote(productId == null ? "" : productId) + "," +
                    points + "," +
                    JSONObject.quote(message == null ? "" : message) +
                    ");}catch(e){console.warn(e);}";
            webView.evaluateJavascript(js, null);
        });
    }

    public void destroy() {
        try { billingClient.endConnection(); } catch (Exception ignored) {}
    }
}
