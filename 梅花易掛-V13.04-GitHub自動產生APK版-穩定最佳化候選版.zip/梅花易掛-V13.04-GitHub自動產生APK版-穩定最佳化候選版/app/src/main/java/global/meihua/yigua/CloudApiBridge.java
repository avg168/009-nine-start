package global.meihua.yigua;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class CloudApiBridge {
    private final Activity activity;
    private final WebView webView;
    private final SecureSessionStore sessionStore;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public CloudApiBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        this.sessionStore = new SecureSessionStore(activity.getApplicationContext());
    }

    @JavascriptInterface
    public boolean isConfigured() {
        return ServerConfig.isConfigured();
    }

    @JavascriptInterface
    public boolean isSignedIn() {
        return !sessionStore.getToken().isEmpty();
    }


    // Native-only: GoogleSignInBridge passes the short-lived Google ID token here.
    // It is not exposed as a JavascriptInterface.
    void loginWithGoogleIdTokenInternal(String idToken) {
        JSONObject body = new JSONObject();
        try {
            body.put("idToken", idToken == null ? "" : idToken);
        } catch (Exception ignored) {}
        request("POST", "/v1/auth/google", body, false, "google_login");
    }

    @JavascriptInterface
    public void register(String email, String password) {
        JSONObject body = new JSONObject();
        try {
            body.put("email", email == null ? "" : email.trim());
            body.put("password", password == null ? "" : password);
        } catch (Exception ignored) {}
        request("POST", "/v1/auth/register", body, false, "register");
    }

    @JavascriptInterface
    public void login(String email, String password) {
        JSONObject body = new JSONObject();
        try {
            body.put("email", email == null ? "" : email.trim());
            body.put("password", password == null ? "" : password);
        } catch (Exception ignored) {}
        request("POST", "/v1/auth/login", body, false, "login");
    }

    @JavascriptInterface
    public void logout() {
        sessionStore.clear();
        callback("logout", true, "{\"ok\":true}");
    }


    @JavascriptInterface
    public void verifyPlayPurchase(String productId, String purchaseToken, int quantity) {
        JSONObject body = new JSONObject();
        try {
            body.put("packageName", "global.meihua.yigua");
            body.put("productId", productId == null ? "" : productId);
            body.put("purchaseToken", purchaseToken == null ? "" : purchaseToken);
            body.put("quantity", Math.max(1, quantity));
        } catch (Exception ignored) {}
        request("POST", "/v1/play/purchases/verify", body, true, "play_verify");
    }

    @JavascriptInterface
    public void getProfile() {
        request("GET", "/v1/me", null, true, "profile");
    }


    @JavascriptInterface
    public void listReadings() {
        request("GET", "/v1/readings", null, true, "readings_list");
    }

    @JavascriptInterface
    public void upsertReading(String readingJson) {
        JSONObject body;
        try {
            body = new JSONObject(readingJson == null ? "{}" : readingJson);
        } catch (Exception e) {
            callback("reading_upsert", false, "{\"error\":\"invalid_reading_json\"}");
            return;
        }
        request("POST", "/v1/readings", body, true, "reading_upsert");
    }

    @JavascriptInterface
    public void deleteReading(String readingId) {
        JSONObject body = new JSONObject();
        try {
            body.put("readingId", readingId == null ? "" : readingId);
        } catch (Exception ignored) {}
        request("POST", "/v1/readings/delete", body, true, "reading_delete");
    }

    @JavascriptInterface
    public void deleteAccount() {
        request("POST", "/v1/account/delete", new JSONObject(), true, "account_delete");
    }

    @JavascriptInterface
    public void getLedger() {
        request("GET", "/v1/points/ledger", null, true, "ledger");
    }

    @JavascriptInterface
    public void spendReadingPoints(String idempotencyKey) {
        JSONObject body = new JSONObject();
        try {
            body.put("cost", 10);
            body.put("idempotencyKey", idempotencyKey == null ? "" : idempotencyKey);
        } catch (Exception ignored) {}
        request("POST", "/v1/readings/spend", body, true, "spend");
    }

    private void request(String method, String path, JSONObject body, boolean auth, String event) {
        if (!ServerConfig.isConfigured()) {
            callback(event, false,
                    "{\"error\":\"cloud_not_configured\",\"message\":\"ServerConfig.BASE_URL is empty\"}");
            return;
        }

        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(ServerConfig.BASE_URL + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod(method);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");

                if (auth) {
                    String token = sessionStore.getToken();
                    if (token.isEmpty()) {
                        callback(event, false, "{\"error\":\"not_signed_in\"}");
                        return;
                    }
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }

                if (body != null) {
                    conn.setDoOutput(true);
                    byte[] data = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(data);
                    }
                }

                int code = conn.getResponseCode();
                InputStream in = code >= 200 && code < 300
                        ? conn.getInputStream() : conn.getErrorStream();
                String response = readAll(in);

                if (code >= 200 && code < 300) {
                    if ("register".equals(event) || "login".equals(event) || "google_login".equals(event)) {
                        try {
                            JSONObject o = new JSONObject(response);
                            String token = o.optString("token", "");
                            if (token.isEmpty() || !sessionStore.saveToken(token)) {
                                callback(event, false, "{\"error\":\"session_save_failed\"}");
                                return;
                            }
                        } catch (Exception e) {
                            callback(event, false, "{\"error\":\"invalid_auth_response\"}");
                            return;
                        }
                    }
                    callback(event, true, response);
                } else {
                    callback(event, false, response == null || response.isEmpty()
                            ? "{\"error\":\"http_" + code + "\"}" : response);
                }
            } catch (Exception e) {
                callback(event, false,
                        "{\"error\":\"network_error\",\"message\":" +
                                JSONObject.quote(e.getClass().getSimpleName()) + "}");
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private void callback(String event, boolean ok, String json) {
        activity.runOnUiThread(() -> {
            if (webView == null) return;
            String safeJson = (json == null || json.isEmpty()) ? "{}" : json;
            String js = "try{if(window.onCloudApiEvent)window.onCloudApiEvent(" +
                    JSONObject.quote(event) + "," + (ok ? "true" : "false") + "," +
                    safeJson + ");}catch(e){console.warn(e);}";
            webView.evaluateJavascript(js, null);
        });
    }

    public void destroy() {
        executor.shutdownNow();
    }
}
