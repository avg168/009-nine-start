/**
 * V12.91 reference pseudocode only.
 * Keep service account credentials on the server.
 */

async function verifyPlayPurchase(req, res) {
  const member = requireAuthenticatedMember(req);
  const { packageName, productId, purchaseToken, quantity = 1 } = req.body;

  if (packageName !== "global.meihua.yigua") return res.status(400).json({status:"rejected"});

  const productPoints = {
    points_100:100,
    points_400:400,
    points_800:800,
    points_2000:2000,
    points_4500:4500,
    points_7000:7000
  };
  if (!productPoints[productId]) return res.status(400).json({status:"rejected"});

  // 1) Query Google Play Developer API using purchaseToken.
  const play = await googlePlayDeveloperApi.getOneTimeProductPurchase({
    packageName, productId, purchaseToken
  });

  // 2) Verify state / product / quantity / account attribution.
  if (!play || play.purchaseState !== "PURCHASED") {
    return res.json({status: play?.purchaseState === "PENDING" ? "pending" : "rejected"});
  }

  // 3) Transaction + purchaseToken unique key => idempotent grant.
  const result = await db.transaction(async tx => {
    const existing = await tx.playPurchases.findByToken(purchaseToken);
    if (existing) return {status:"already_granted", balance:await tx.members.balance(member.id)};

    const points = productPoints[productId] * Math.max(1, quantity);
    const balance = await tx.members.incrementPoints(member.id, points);
    await tx.playPurchases.insert({purchaseToken, memberId:member.id, productId, pointsGranted:points});
    await tx.pointLedger.insert({
      memberId:member.id, sourceType:"play_purchase", sourceId:purchaseToken,
      delta:points, balanceAfter:balance, idempotencyKey:"play:"+purchaseToken
    });
    return {status:"granted", pointsGranted:points, balance};
  });

  // 4) Consume only after durable entitlement grant.
  if (result.status === "granted") {
    await googlePlayDeveloperApi.consume({packageName, productId, purchaseToken});
  }

  res.json(result);
}
