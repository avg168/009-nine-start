# 梅花易掛 V12.91 安全後端範本

這個資料夾是「參考架構」，不是已部署的正式伺服器。

正式 Production 建議流程：

1. App 完成 Google Play 購買後，只把 `purchaseToken`、`productId`、`quantity` 與已登入會員身份送到後端。
2. 後端使用 Google Play Developer API 驗證 purchase token。
3. 後端確認：
   - packageName = `global.meihua.yigua`
   - Product ID 合法
   - purchase state 合法
   - purchaseToken 未被處理過
   - 購買對應目前會員
4. 後端使用資料庫 transaction：
   - 寫入 purchase token（唯一鍵）
   - 增加會員點數
   - 寫入點數 ledger
5. 後端再執行 consume / acknowledge 所需流程。
6. App 只顯示後端回傳的權威點數餘額。
7. RTDN / voided purchase 到達時，後端重新查 Google Play Developer API，再做退款追回或帳務調整。

不要：
- 把 Google service account private key 放進 APK
- 只靠 SharedPreferences 當正式點數帳本
- 只相信 App 傳來的 price / points
- 只因 purchase callback 成功就直接在手機加正式點數
