/**
 * RTDN reference pseudocode.
 * RTDN says "something changed"; query Google Play Developer API for full state.
 */
async function handleGoogleRtdn(pubsubMessage) {
  if (await seenMessageId(pubsubMessage.messageId)) return;

  const event = decodeBase64Json(pubsubMessage.data);

  if (event.voidedPurchaseNotification) {
    const token = event.voidedPurchaseNotification.purchaseToken;

    // Look up original member/purchase by globally unique purchase token.
    const purchase = await db.playPurchases.findByToken(token);
    if (!purchase) return;

    // Query Google Play / Voided Purchases API as appropriate.
    // Decide clawback policy. Never let balance become negative without explicit policy.
    await db.transaction(async tx => {
      const current = await tx.members.balance(purchase.memberId);
      const clawback = Math.min(current, purchase.pointsGranted);
      const next = current - clawback;

      await tx.members.setPoints(purchase.memberId, next);
      await tx.playPurchases.markVoided(token);
      await tx.pointLedger.insert({
        memberId:purchase.memberId,
        sourceType:"play_refund",
        sourceId:token,
        delta:-clawback,
        balanceAfter:next,
        idempotencyKey:"void:"+token
      });
    });
  }
}
