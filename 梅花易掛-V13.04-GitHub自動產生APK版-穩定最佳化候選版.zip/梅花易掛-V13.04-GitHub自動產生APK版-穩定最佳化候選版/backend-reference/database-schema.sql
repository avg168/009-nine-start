-- V12.91 reference schema (PostgreSQL style)

create table members (
  id uuid primary key,
  email text unique,
  points bigint not null default 0 check (points >= 0),
  created_at timestamptz not null default now()
);

create table play_purchases (
  purchase_token text primary key,
  member_id uuid not null references members(id),
  product_id text not null,
  quantity integer not null default 1,
  points_granted integer not null,
  order_id text,
  purchase_state text not null,
  consumed boolean not null default false,
  voided boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table point_ledger (
  id uuid primary key,
  member_id uuid not null references members(id),
  source_type text not null,
  source_id text,
  delta bigint not null,
  balance_after bigint not null check (balance_after >= 0),
  idempotency_key text unique,
  created_at timestamptz not null default now()
);

create index point_ledger_member_created_idx
  on point_ledger(member_id, created_at desc);
