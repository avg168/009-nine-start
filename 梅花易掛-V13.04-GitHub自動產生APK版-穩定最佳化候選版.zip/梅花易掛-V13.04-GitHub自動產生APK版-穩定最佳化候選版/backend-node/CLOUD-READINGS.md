# V12.96｜卦象雲端同步

API：
- GET /v1/readings
- POST /v1/readings
- POST /v1/readings/delete
- POST /v1/account/delete

設計：
- 每位會員的 readingId 唯一。
- payload 使用 jsonb 保存完整卦象資料。
- upsert 防止重複同步。
- 本機仍保留歷史紀錄，雲端作同步／恢復用途。
- 換手機後登入同一會員，再呼叫 GET /v1/readings 即可恢復。
- 單筆 payload 上限 200 KB。
- 帳號刪除時，cloud_readings 使用 cascade 全刪。

帳務資料：
Play purchase / point ledger 可能有交易稽核需求，因此 V12.96 的 account delete
會先移除與會員身份的直接關聯，再刪除 members。正式營運時仍須依所在地法規與
實際會計／稅務保存需求制定 retention policy。
