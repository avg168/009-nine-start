create table if not exists account_delete_tokens (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references members(id) on delete cascade,
  token_hash text not null unique,
  request_ip_hash text,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists account_delete_tokens_member_idx
  on account_delete_tokens(member_id,created_at desc);

create index if not exists account_delete_tokens_expiry_idx
  on account_delete_tokens(expires_at)
  where used_at is null;
