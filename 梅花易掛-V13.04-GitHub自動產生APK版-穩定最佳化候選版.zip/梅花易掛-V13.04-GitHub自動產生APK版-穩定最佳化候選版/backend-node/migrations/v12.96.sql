alter table play_purchases
  alter column member_id drop not null;

alter table point_ledger
  alter column member_id drop not null;

alter table play_purchases
  drop constraint if exists play_purchases_member_id_fkey;

alter table play_purchases
  add constraint play_purchases_member_id_fkey
  foreign key(member_id) references members(id) on delete set null;

alter table point_ledger
  drop constraint if exists point_ledger_member_id_fkey;

alter table point_ledger
  add constraint point_ledger_member_id_fkey
  foreign key(member_id) references members(id) on delete set null;

create table if not exists cloud_readings (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references members(id) on delete cascade,
  reading_id text not null,
  payload jsonb not null,
  client_updated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(member_id,reading_id)
);

create index if not exists cloud_readings_member_updated_idx
  on cloud_readings(member_id,updated_at desc);
