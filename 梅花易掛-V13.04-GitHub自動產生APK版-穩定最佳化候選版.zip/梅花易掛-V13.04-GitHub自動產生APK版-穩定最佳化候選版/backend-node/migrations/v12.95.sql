alter table members
  alter column password_hash drop not null;

alter table members
  add column if not exists google_sub text,
  add column if not exists display_name text,
  add column if not exists picture_url text;

create unique index if not exists members_google_sub_uq
  on members(google_sub)
  where google_sub is not null;
