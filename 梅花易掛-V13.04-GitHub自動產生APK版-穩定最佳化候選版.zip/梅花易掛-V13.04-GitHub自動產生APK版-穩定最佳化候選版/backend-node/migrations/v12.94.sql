alter table play_purchases
  add column if not exists voided boolean not null default false;

create table if not exists rtdn_messages (
  message_id text primary key,
  event_type text not null,
  payload jsonb not null,
  received_at timestamptz not null default now()
);

create index if not exists rtdn_messages_received_idx
on rtdn_messages(received_at desc);
