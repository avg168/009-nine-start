create extension if not exists pgcrypto;

create table if not exists members (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  password_hash text,
  google_sub text unique,
  display_name text,
  picture_url text,
  points bigint not null default 0 check(points >= 0),
  created_at timestamptz not null default now()
);

create table if not exists play_purchases (
  purchase_token text primary key,
  member_id uuid references members(id) on delete set null,
  product_id text not null,
  points_granted integer not null,
  purchase_state text not null,
  order_id text,
  voided boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists point_ledger (
  id uuid primary key default gen_random_uuid(),
  member_id uuid references members(id) on delete set null,
  source_type text not null,
  source_id text,
  delta bigint not null,
  balance_after bigint not null check(balance_after >= 0),
  idempotency_key text,
  created_at timestamptz not null default now(),
  unique(member_id,idempotency_key)
);

create index if not exists point_ledger_member_created_idx
on point_ledger(member_id,created_at desc);


create table if not exists rtdn_messages (
  message_id text primary key,
  event_type text not null,
  payload jsonb not null,
  received_at timestamptz not null default now()
);

create index if not exists rtdn_messages_received_idx
on rtdn_messages(received_at desc);


create table if not exists cloud_readings (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references members(id) on delete cascade,
  reading_id text not null,
  payload jsonb not null,
  client_updated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique(member_id,reading_id)
);

create index if not exists cloud_readings_member_updated_idx
  on cloud_readings(member_id,updated_at desc);


create table if not exists account_delete_tokens (
  id uuid primary key default gen_random_uuid(),
  member_id uuid not null references members(id) on delete cascade,
  token_hash text not null unique,
  request_ip_hash text,
  expires_at timestamptz not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists account_delete_tokens_member_idx
  on account_delete_tokens(member_id,created_at desc);

create index if not exists account_delete_tokens_expiry_idx
  on account_delete_tokens(expires_at)
  where used_at is null;
