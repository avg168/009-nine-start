# V12.98 後端部署清單

已新增真正的 Google Play purchaseToken 後端驗證流程。

正式功能：
- Email 註冊／登入
- JWT session
- 雲端會員點數
- PostgreSQL ledger
- 起卦伺服器扣 10 點
- Google Play purchaseToken 驗證
- purchaseToken 唯一鍵防重複授權
- PURCHASED 才入點
- PENDING / canceled 不入點
- durable grant 後才 server-side consume
- consume 失敗時標記 PURCHASED_NEEDS_CONSUME，可重試

部署前：
1. 建立 PostgreSQL 並執行 schema.sql。
2. 設定 DATABASE_URL。
3. 設定至少 32 字元以上隨機 JWT_SECRET。
4. 建立 Google Cloud service account。
5. 啟用 Google Play Android Developer API。
6. 在 Play Console 授權 service account 存取 App。
7. 將 service account JSON 安全放在伺服器，不可放進 APK。
8. 設定 GOOGLE_SERVICE_ACCOUNT_JSON 為該檔案路徑。
9. 設定 GOOGLE_PLAY_PACKAGE=global.meihua.yigua。
10. 部署 HTTPS。
11. Android 的 ServerConfig.BASE_URL 改成正式 HTTPS 網址。
12. 重新產生 Signed AAB，透過 Internal testing 真機測試。

重要：
- purchaseToken 是交易唯一鍵。
- 不用 orderId 當資料庫主鍵。
- PENDING 時不得授權。
- 點數寫入資料庫 transaction 成功後才 consume。


## RTDN / 退款撤銷
完成基本購買驗證後，再依 `RTDN-SETUP.md` 建立 Pub/Sub。
正式商用前至少測試：
- test notification
- one-time product 狀態通知
- full refund / voided purchase
- 同一 messageId 重送
- App 點數已部分使用時的追回結果


## Sign in with Google / Credential Manager
1. 在 Google Cloud / Google Auth Platform 建立 OAuth 2.0「Web application」Client ID。
2. 將同一個 Web Client ID：
   - 填入 Android `ServerConfig.GOOGLE_WEB_CLIENT_ID`
   - 填入後端 `GOOGLE_WEB_CLIENT_ID`
3. 正式 Android App 的 package 保持 `global.meihua.yigua`。
4. 依 Google Auth Platform 要求完成 App/品牌設定與驗證。
5. Android 取得 Google ID token 後，不保存在 WebView；直接 native -> backend。
6. 後端 `/v1/auth/google` 會驗證 ID token audience，再使用 Google `sub` 綁定會員。
7. 會員 session 仍由梅花易掛後端簽發並由 Android Keystore 加密保存。


## Cloud readings
執行 `migrations/v12.96.sql` 後啟用：
- /v1/readings
- /v1/readings/delete
- /v1/account/delete

因 V12.98 開始處理會員帳號與歷史卦象雲端資料，正式上線前必須同步更新：
- Privacy Policy
- Play Console Data safety
- Account deletion web resource


## V12.98 external account deletion
Google Play 要求帳號刪除同時提供 App 內與外部網頁入口。
`account-deletion-web/` 可作為公開頁面的起點，但正式上線前必須接上安全身分驗證與真正刪除 API。


## V12.98 Account deletion email verification
必要環境變數：
- ACCOUNT_DELETE_CONFIRM_BASE_URL
- ACCOUNT_DELETE_TTL_MINUTES
- SMTP_HOST
- SMTP_PORT
- SMTP_USER
- SMTP_PASS
- SMTP_FROM

執行 `migrations/v12.98.sql`。
正式對外前，在 API Gateway / reverse proxy 增加 request rate limiting。
刪除請求的 API 回應不得透露 Email 是否存在。
