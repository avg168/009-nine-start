import express from "express";
import crypto from "node:crypto";
import { promisify } from "node:util";
import pg from "pg";
import { SignJWT, jwtVerify } from "jose";
import { google } from "googleapis";
import { OAuth2Client } from "google-auth-library";
import nodemailer from "nodemailer";

const scryptAsync = promisify(crypto.scrypt);
const app = express();
app.use(express.json({ limit: "64kb" }));

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const secretText = process.env.JWT_SECRET || "";
if (secretText.length < 32) {
  console.warn("WARNING: JWT_SECRET should be at least 32 random characters.");
}
const jwtSecret = new TextEncoder().encode(secretText || "DEV_ONLY_CHANGE_ME_12345678901234567890");

const PRODUCTS = {
  points_100:100, points_400:400, points_800:800,
  points_2000:2000, points_4500:4500, points_7000:7000
};

function normalizeEmail(v) {
  return String(v || "").trim().toLowerCase();
}
function validEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}
async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scryptAsync(password, salt, 64);
  return `scrypt$${salt.toString("base64")}$${Buffer.from(key).toString("base64")}`;
}
async function verifyPassword(password, stored) {
  const [alg, saltB64, keyB64] = String(stored || "").split("$");
  if (alg !== "scrypt" || !saltB64 || !keyB64) return false;
  const salt = Buffer.from(saltB64, "base64");
  const expected = Buffer.from(keyB64, "base64");
  const actual = Buffer.from(await scryptAsync(password, salt, expected.length));
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}
async function issueToken(member) {
  return new SignJWT({ email: member.email })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(String(member.id))
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(jwtSecret);
}
async function auth(req, res, next) {
  try {
    const h = req.headers.authorization || "";
    if (!h.startsWith("Bearer ")) return res.status(401).json({error:"unauthorized"});
    const { payload } = await jwtVerify(h.slice(7), jwtSecret);
    req.memberId = payload.sub;
    next();
  } catch {
    res.status(401).json({error:"unauthorized"});
  }
}



const GOOGLE_WEB_CLIENT_ID = process.env.GOOGLE_WEB_CLIENT_ID || "";
const googleOAuthClient = new OAuth2Client(GOOGLE_WEB_CLIENT_ID);


const ACCOUNT_DELETE_TTL_MINUTES = Math.max(10, Math.min(120, Number(process.env.ACCOUNT_DELETE_TTL_MINUTES || 30)));

function sha256Hex(value) {
  return crypto.createHash("sha256").update(String(value || ""), "utf8").digest("hex");
}

function base64UrlRandom(bytes = 32) {
  return crypto.randomBytes(bytes).toString("base64url");
}

function genericDeletionRequestResponse(res) {
  return res.json({
    ok:true,
    message:"If an eligible account exists, a confirmation email will be sent."
  });
}

function getDeleteConfirmBaseUrl() {
  const url = String(process.env.ACCOUNT_DELETE_CONFIRM_BASE_URL || "");
  if (!/^https:\/\/[^ ]+/i.test(url)) throw new Error("ACCOUNT_DELETE_CONFIRM_BASE_URL_not_configured");
  return url.replace(/\/+$/,"");
}

function getMailer() {
  const host = String(process.env.SMTP_HOST || "");
  const port = Number(process.env.SMTP_PORT || 587);
  const user = String(process.env.SMTP_USER || "");
  const pass = String(process.env.SMTP_PASS || "");
  const from = String(process.env.SMTP_FROM || "");
  if (!host || !user || !pass || !from) throw new Error("SMTP_not_configured");
  return {
    from,
    transport:nodemailer.createTransport({
      host,
      port,
      secure:port === 465,
      auth:{user,pass}
    })
  };
}

async function sendAccountDeletionEmail(email, rawToken) {
  const {from,transport} = getMailer();
  const base = getDeleteConfirmBaseUrl();
  const confirmUrl = `${base}?token=${encodeURIComponent(rawToken)}`;
  await transport.sendMail({
    from,
    to:email,
    subject:"梅花易掛｜確認刪除會員帳號",
    text:
`您收到這封信，是因為有人提出刪除「梅花易掛」會員帳號的請求。

若是您本人提出，請在 ${ACCOUNT_DELETE_TTL_MINUTES} 分鐘內開啟以下 HTTPS 連結確認：
${confirmUrl}

完成確認後，會員帳號與相關雲端卦象資料將被刪除。
若不是您提出，請忽略此信。

基於安全性，此連結只能使用一次。`
  });
}

async function performAccountDeletion(client, memberId) {
  await client.query(`delete from cloud_readings where member_id=$1`,[memberId]);
  await client.query(`update play_purchases set member_id=null where member_id=$1`,[memberId]);
  await client.query(`update point_ledger set member_id=null where member_id=$1`,[memberId]);
  await client.query(`delete from account_delete_tokens where member_id=$1`,[memberId]);
  await client.query(`delete from members where id=$1`,[memberId]);
}

const PLAY_PACKAGE = process.env.GOOGLE_PLAY_PACKAGE || "global.meihua.yigua";

async function getAndroidPublisher() {
  const keyFile = process.env.GOOGLE_SERVICE_ACCOUNT_JSON || "";
  if (!keyFile) throw new Error("GOOGLE_SERVICE_ACCOUNT_JSON_not_configured");
  const auth = new google.auth.GoogleAuth({
    keyFile,
    scopes: ["https://www.googleapis.com/auth/androidpublisher"]
  });
  return google.androidpublisher({ version: "v3", auth });
}

async function fetchPlayProductPurchase(productId, purchaseToken) {
  const publisher = await getAndroidPublisher();
  const r = await publisher.purchases.products.get({
    packageName: PLAY_PACKAGE,
    productId,
    token: purchaseToken
  });
  return r.data || {};
}

async function consumePlayProduct(productId, purchaseToken) {
  const publisher = await getAndroidPublisher();
  await publisher.purchases.products.consume({
    packageName: PLAY_PACKAGE,
    productId,
    token: purchaseToken
  });
}

app.get("/health", (_req,res)=>res.json({ok:true, version:"13.01"}));

app.post("/v1/auth/register", async (req,res)=>{
  const email = normalizeEmail(req.body.email);
  const password = String(req.body.password || "");
  if (!validEmail(email)) return res.status(400).json({error:"invalid_email"});
  if (password.length < 8 || password.length > 200) return res.status(400).json({error:"invalid_password"});
  try {
    const hash = await hashPassword(password);
    const q = await pool.query(
      `insert into members(email,password_hash,points)
       values($1,$2,0)
       returning id,email,points`,
      [email, hash]
    );
    const member = q.rows[0];
    res.status(201).json({token:await issueToken(member), member});
  } catch (e) {
    if (e && e.code === "23505") return res.status(409).json({error:"email_exists"});
    console.error(e);
    res.status(500).json({error:"server_error"});
  }
});

app.post("/v1/auth/login", async (req,res)=>{
  const email = normalizeEmail(req.body.email);
  const password = String(req.body.password || "");
  const q = await pool.query(
    `select id,email,password_hash,points from members where email=$1`, [email]
  );
  const member = q.rows[0];
  if (!member || !(await verifyPassword(password, member.password_hash))) {
    return res.status(401).json({error:"invalid_credentials"});
  }
  res.json({
    token:await issueToken(member),
    member:{id:member.id,email:member.email,points:Number(member.points)}
  });
});


app.post("/v1/auth/google", async (req,res)=>{
  const idToken = String(req.body.idToken || "");
  if (!GOOGLE_WEB_CLIENT_ID) {
    return res.status(503).json({error:"google_oauth_not_configured"});
  }
  if (idToken.length < 100) {
    return res.status(400).json({error:"invalid_google_token"});
  }

  let payload;
  try {
    const ticket = await googleOAuthClient.verifyIdToken({
      idToken,
      audience: GOOGLE_WEB_CLIENT_ID
    });
    payload = ticket.getPayload();
  } catch(e) {
    console.error("Google ID token verify failed", e);
    return res.status(401).json({error:"invalid_google_token"});
  }

  const googleSub = String(payload?.sub || "");
  const email = normalizeEmail(payload?.email || "");
  const emailVerified = payload?.email_verified === true;
  const name = String(payload?.name || "").slice(0,200);
  const picture = String(payload?.picture || "").slice(0,1000);

  if (!googleSub || !email || !emailVerified) {
    return res.status(401).json({error:"google_identity_incomplete"});
  }

  const client = await pool.connect();
  try {
    await client.query("begin");

    let q = await client.query(
      `select id,email,points,google_sub from members where google_sub=$1 for update`,
      [googleSub]
    );
    let member = q.rows[0];

    if (!member) {
      // A verified Google email may link to an existing local account with the same email.
      q = await client.query(
        `select id,email,points,google_sub from members where email=$1 for update`,
        [email]
      );
      member = q.rows[0];

      if (member) {
        if (member.google_sub && member.google_sub !== googleSub) {
          await client.query("rollback");
          return res.status(409).json({error:"email_link_conflict"});
        }
        q = await client.query(
          `update members
              set google_sub=$1,display_name=coalesce(nullif($2,''),display_name),
                  picture_url=coalesce(nullif($3,''),picture_url)
            where id=$4
            returning id,email,points,google_sub`,
          [googleSub,name,picture,member.id]
        );
        member = q.rows[0];
      } else {
        q = await client.query(
          `insert into members(email,password_hash,points,google_sub,display_name,picture_url)
           values($1,null,0,$2,$3,$4)
           returning id,email,points,google_sub`,
          [email,googleSub,name,picture]
        );
        member = q.rows[0];
      }
    } else {
      await client.query(
        `update members
            set display_name=coalesce(nullif($1,''),display_name),
                picture_url=coalesce(nullif($2,''),picture_url)
          where id=$3`,
        [name,picture,member.id]
      );
    }

    await client.query("commit");
    return res.json({
      token: await issueToken(member),
      member:{id:member.id,email:member.email,points:Number(member.points)},
      provider:"google"
    });
  } catch(e) {
    await client.query("rollback").catch(()=>{});
    console.error(e);
    return res.status(500).json({error:"server_error"});
  } finally {
    client.release();
  }
});

app.get("/v1/me", auth, async (req,res)=>{
  const q = await pool.query(
    `select id,email,points,created_at from members where id=$1`, [req.memberId]
  );
  if (!q.rows[0]) return res.status(404).json({error:"member_not_found"});
  const m=q.rows[0];
  res.json({id:m.id,email:m.email,points:Number(m.points),createdAt:m.created_at});
});


app.get("/v1/readings", auth, async (req,res)=>{
  const q = await pool.query(
    `select reading_id,payload,updated_at,created_at
       from cloud_readings
      where member_id=$1 and deleted_at is null
      order by updated_at desc
      limit 500`,
    [req.memberId]
  );
  res.json({
    items:q.rows.map(r=>({
      readingId:r.reading_id,
      payload:r.payload,
      updatedAt:r.updated_at,
      createdAt:r.created_at
    }))
  });
});

app.post("/v1/readings", auth, async (req,res)=>{
  const readingId = String(req.body.readingId || "");
  const payload = req.body.payload;
  const clientUpdatedAt = String(req.body.clientUpdatedAt || "");

  if (!/^[A-Za-z0-9._:-]{8,100}$/.test(readingId)) {
    return res.status(400).json({error:"invalid_reading_id"});
  }
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    return res.status(400).json({error:"invalid_payload"});
  }

  const serialized = JSON.stringify(payload);
  if (Buffer.byteLength(serialized,"utf8") > 200000) {
    return res.status(413).json({error:"reading_too_large"});
  }

  const q = await pool.query(
    `insert into cloud_readings(member_id,reading_id,payload,client_updated_at)
     values($1,$2,$3::jsonb,nullif($4,'')::timestamptz)
     on conflict(member_id,reading_id)
     do update set
       payload=excluded.payload,
       client_updated_at=excluded.client_updated_at,
       updated_at=now(),
       deleted_at=null
     where cloud_readings.client_updated_at is null
        or excluded.client_updated_at is null
        or excluded.client_updated_at >= cloud_readings.client_updated_at
     returning reading_id,updated_at`,
    [req.memberId,readingId,serialized,clientUpdatedAt]
  );
  if (!q.rows[0]) {
    const current = await pool.query(
      `select reading_id,payload,updated_at,client_updated_at
         from cloud_readings where member_id=$1 and reading_id=$2`,
      [req.memberId,readingId]
    );
    return res.status(409).json({
      error:"cloud_newer",
      current:current.rows[0] || null
    });
  }
  res.json({ok:true,readingId:q.rows[0].reading_id,updatedAt:q.rows[0].updated_at});
});

app.post("/v1/readings/delete", auth, async (req,res)=>{
  const readingId = String(req.body.readingId || "");
  if (!/^[A-Za-z0-9._:-]{8,100}$/.test(readingId)) {
    return res.status(400).json({error:"invalid_reading_id"});
  }
  await pool.query(
    `update cloud_readings set deleted_at=now(),updated_at=now()
      where member_id=$1 and reading_id=$2`,
    [req.memberId,readingId]
  );
  res.json({ok:true});
});

app.post("/v1/account/delete", auth, async (req,res)=>{
  const client = await pool.connect();
  try {
    await client.query("begin");

    // Keep irreversible financial/audit rows anonymized where legally/accounting required;
    // delete profile, auth identifiers and cloud reading content immediately.
    await performAccountDeletion(client,req.memberId);

    await client.query("commit");
    res.json({ok:true,deleted:true});
  } catch(e) {
    await client.query("rollback").catch(()=>{});
    console.error(e);
    res.status(500).json({error:"account_delete_failed"});
  } finally {
    client.release();
  }
});

app.get("/v1/points/ledger", auth, async (req,res)=>{
  const q = await pool.query(
    `select source_type,source_id,delta,balance_after,created_at
       from point_ledger where member_id=$1
      order by created_at desc limit 200`, [req.memberId]
  );
  res.json({items:q.rows});
});

app.post("/v1/readings/spend", auth, async (req,res)=>{
  const cost = 10; // Never trust cost sent by client.
  const key = String(req.body.idempotencyKey || "");
  if (key.length < 8 || key.length > 100) return res.status(400).json({error:"invalid_idempotency_key"});

  const client = await pool.connect();
  try {
    await client.query("begin");
    const prior = await client.query(
      `select balance_after from point_ledger
        where idempotency_key=$1 and member_id=$2`, [key, req.memberId]
    );
    if (prior.rows[0]) {
      await client.query("commit");
      return res.json({ok:true,idempotent:true,balance:Number(prior.rows[0].balance_after)});
    }

    const lock = await client.query(
      `select points from members where id=$1 for update`, [req.memberId]
    );
    if (!lock.rows[0]) throw new Error("member_not_found");
    const before = Number(lock.rows[0].points);
    if (before < cost) {
      await client.query("rollback");
      return res.status(409).json({error:"insufficient_points",balance:before});
    }
    const after = before-cost;
    await client.query(`update members set points=$1 where id=$2`,[after,req.memberId]);
    await client.query(
      `insert into point_ledger(member_id,source_type,source_id,delta,balance_after,idempotency_key)
       values($1,'reading',$2,$3,$4,$5)`,
      [req.memberId,key,-cost,after,key]
    );
    await client.query("commit");
    res.json({ok:true,balance:after});
  } catch(e) {
    await client.query("rollback").catch(()=>{});
    console.error(e);
    res.status(500).json({error:"server_error"});
  } finally {
    client.release();
  }
});

/**
 * Secure Google Play one-time product verification.
 * The purchase token is the idempotency key / primary key.
 * Entitlement is granted only for PURCHASED transactions.
 */
app.post("/v1/play/purchases/verify", auth, async (req,res)=>{
  const productId = String(req.body.productId || "");
  const purchaseToken = String(req.body.purchaseToken || "");
  const requestedQuantity = Math.max(1, Number(req.body.quantity || 1));
  const pointsEach = PRODUCTS[productId];

  if (!pointsEach || purchaseToken.length < 10) {
    return res.status(400).json({error:"invalid_purchase"});
  }

  if (!process.env.GOOGLE_SERVICE_ACCOUNT_JSON) {
    return res.status(503).json({
      error:"google_play_verification_not_configured",
      message:"Set GOOGLE_SERVICE_ACCOUNT_JSON before Production."
    });
  }

  let play;
  try {
    play = await fetchPlayProductPurchase(productId, purchaseToken);
  } catch (e) {
    console.error("Play verify failed", e?.response?.data || e);
    return res.status(502).json({error:"google_play_verify_failed"});
  }

  // Google Play products API: purchaseState 0 = purchased, 1 = canceled, 2 = pending.
  if (play.purchaseState === 2) {
    return res.status(409).json({status:"pending", error:"purchase_pending"});
  }
  if (play.purchaseState !== 0) {
    return res.status(409).json({status:"rejected", error:"purchase_not_purchased"});
  }

  const quantity = Math.max(1, Number(play.quantity || requestedQuantity || 1));
  const pointsToGrant = pointsEach * quantity;

  const client = await pool.connect();
  let result;
  try {
    await client.query("begin");

    const existing = await client.query(
      `select member_id,product_id,points_granted,purchase_state
         from play_purchases
        where purchase_token=$1
        for update`,
      [purchaseToken]
    );

    if (existing.rows[0]) {
      const row = existing.rows[0];
      if (String(row.member_id) !== String(req.memberId)) {
        await client.query("rollback");
        return res.status(409).json({error:"purchase_token_owned_by_other_member"});
      }

      const q = await client.query(
        `select points from members where id=$1`,
        [req.memberId]
      );
      await client.query("commit");
      return res.json({
        status:"already_granted",
        pointsGranted:Number(row.points_granted),
        balance:Number(q.rows[0]?.points || 0)
      });
    }

    const lock = await client.query(
      `select points from members where id=$1 for update`,
      [req.memberId]
    );
    if (!lock.rows[0]) throw new Error("member_not_found");

    const before = Number(lock.rows[0].points);
    const after = before + pointsToGrant;

    await client.query(
      `insert into play_purchases(
         purchase_token,member_id,product_id,points_granted,purchase_state,order_id
       ) values($1,$2,$3,$4,'PURCHASED',$5)`,
      [purchaseToken, req.memberId, productId, pointsToGrant, play.orderId || null]
    );

    await client.query(
      `update members set points=$1 where id=$2`,
      [after, req.memberId]
    );

    await client.query(
      `insert into point_ledger(
         member_id,source_type,source_id,delta,balance_after,idempotency_key
       ) values($1,'play_purchase',$2,$3,$4,$5)`,
      [req.memberId, purchaseToken, pointsToGrant, after, "play:"+purchaseToken]
    );

    await client.query("commit");
    result = {status:"granted", pointsGranted:pointsToGrant, balance:after};
  } catch(e) {
    await client.query("rollback").catch(()=>{});
    if (e?.code === "23505") {
      const q = await pool.query(`select points from members where id=$1`,[req.memberId]);
      return res.json({status:"already_granted",balance:Number(q.rows[0]?.points||0)});
    }
    console.error(e);
    return res.status(500).json({error:"server_error"});
  } finally {
    client.release();
  }

  // Consume only AFTER durable entitlement grant.
  try {
    await consumePlayProduct(productId, purchaseToken);
    await pool.query(
      `update play_purchases set purchase_state='PURCHASED_CONSUMED',updated_at=now()
        where purchase_token=$1`,
      [purchaseToken]
    );
  } catch(e) {
    // Points remain safely granted; retry consumption later.
    console.error("Play consume failed; retry required", e?.response?.data || e);
    await pool.query(
      `update play_purchases set purchase_state='PURCHASED_NEEDS_CONSUME',updated_at=now()
        where purchase_token=$1`,
      [purchaseToken]
    ).catch(()=>{});
    result.consumePending = true;
  }

  return res.json(result);
});


app.post("/v1/play/purchases/retry-consume", auth, async (req,res)=>{
  const token = String(req.body.purchaseToken || "");
  const q = await pool.query(
    `select product_id,member_id,purchase_state from play_purchases where purchase_token=$1`,
    [token]
  );
  const p = q.rows[0];
  if (!p || String(p.member_id) !== String(req.memberId)) {
    return res.status(404).json({error:"purchase_not_found"});
  }
  if (p.purchase_state === "PURCHASED_CONSUMED") {
    return res.json({ok:true,alreadyConsumed:true});
  }
  try {
    await consumePlayProduct(p.product_id, token);
    await pool.query(
      `update play_purchases set purchase_state='PURCHASED_CONSUMED',updated_at=now()
        where purchase_token=$1`, [token]
    );
    res.json({ok:true});
  } catch(e) {
    console.error(e?.response?.data || e);
    res.status(502).json({error:"consume_retry_failed"});
  }
});


function decodeRtdnEnvelope(reqBody) {
  const message = reqBody?.message;
  if (!message || !message.data || !message.messageId) {
    throw new Error("invalid_pubsub_envelope");
  }
  const raw = Buffer.from(message.data, "base64").toString("utf8");
  return {
    messageId: String(message.messageId),
    publishTime: message.publishTime || null,
    event: JSON.parse(raw)
  };
}

async function isRtdnMessageProcessed(client, messageId) {
  const q = await client.query(
    `select message_id from rtdn_messages where message_id=$1`,
    [messageId]
  );
  return !!q.rows[0];
}

async function recordRtdnMessage(client, messageId, eventType, payload) {
  await client.query(
    `insert into rtdn_messages(message_id,event_type,payload)
     values($1,$2,$3::jsonb)
     on conflict(message_id) do nothing`,
    [messageId, eventType, JSON.stringify(payload)]
  );
}

async function applyVoidedPurchase({purchaseToken, orderId, refundType}) {
  const client = await pool.connect();
  try {
    await client.query("begin");

    const pq = await client.query(
      `select purchase_token,member_id,product_id,points_granted,voided
         from play_purchases
        where purchase_token=$1
        for update`,
      [purchaseToken]
    );
    const purchase = pq.rows[0];
    if (!purchase) {
      await client.query("commit");
      return {status:"purchase_not_found"};
    }
    if (purchase.voided) {
      const mq = await client.query(`select points from members where id=$1`,[purchase.member_id]);
      await client.query("commit");
      return {status:"already_voided", balance:Number(mq.rows[0]?.points||0)};
    }

    const mq = await client.query(
      `select points from members where id=$1 for update`,
      [purchase.member_id]
    );
    if (!mq.rows[0]) throw new Error("member_not_found");

    const current = Number(mq.rows[0].points);
    const fullGrant = Number(purchase.points_granted || 0);

    // V12.94 conservative policy:
    // Full refunds claw back up to the current available balance.
    // Quantity partial refunds are recorded for review because original per-unit
    // refundable quantity should be verified with the Google Play API first.
    if (Number(refundType) === 2) {
      await client.query(
        `update play_purchases
            set purchase_state='PARTIAL_REFUND_REVIEW', updated_at=now()
          where purchase_token=$1`,
        [purchaseToken]
      );
      await client.query("commit");
      return {status:"partial_refund_review_required", balance:current};
    }

    const clawback = Math.min(current, fullGrant);
    const after = current - clawback;

    await client.query(`update members set points=$1 where id=$2`,[after,purchase.member_id]);
    await client.query(
      `update play_purchases
          set voided=true,purchase_state='VOIDED',updated_at=now()
        where purchase_token=$1`,
      [purchaseToken]
    );
    await client.query(
      `insert into point_ledger(
         member_id,source_type,source_id,delta,balance_after,idempotency_key
       ) values($1,'play_refund',$2,$3,$4,$5)
       on conflict(member_id,idempotency_key) do nothing`,
      [purchase.member_id,purchaseToken,-clawback,after,"void:"+purchaseToken]
    );

    await client.query("commit");
    return {
      status:"voided",
      pointsClawedBack:clawback,
      unpaidClawback:Math.max(0,fullGrant-clawback),
      balance:after
    };
  } catch(e) {
    await client.query("rollback").catch(()=>{});
    throw e;
  } finally {
    client.release();
  }
}

/**
 * Google Play RTDN via Pub/Sub push.
 * RTDN only signals a state change; query Google Play Developer API as needed
 * before making entitlement decisions.
 */
app.post("/v1/google/rtdn", async (req,res)=>{
  let decoded;
  try {
    decoded = decodeRtdnEnvelope(req.body);
  } catch(e) {
    return res.status(400).json({error:"invalid_rtdn"});
  }

  const {messageId,event} = decoded;
  if (event.packageName && event.packageName !== PLAY_PACKAGE) {
    return res.status(400).json({error:"wrong_package"});
  }

  const client = await pool.connect();
  try {
    await client.query("begin");
    if (await isRtdnMessageProcessed(client,messageId)) {
      await client.query("commit");
      return res.status(204).end();
    }

    let eventType="unknown";
    if (event.voidedPurchaseNotification) eventType="voided_purchase";
    else if (event.oneTimeProductNotification) eventType="one_time_product";
    else if (event.testNotification) eventType="test";

    await recordRtdnMessage(client,messageId,eventType,event);
    await client.query("commit");
  } catch(e) {
    await client.query("rollback").catch(()=>{});
    console.error("RTDN dedupe failed",e);
    return res.status(500).json({error:"rtdn_store_failed"});
  } finally {
    client.release();
  }

  try {
    if (event.voidedPurchaseNotification) {
      const v = event.voidedPurchaseNotification;
      const result = await applyVoidedPurchase({
        purchaseToken:String(v.purchaseToken||""),
        orderId:String(v.orderId||""),
        refundType:Number(v.refundType||1)
      });
      console.log("RTDN voided purchase processed",messageId,result);
    } else if (event.oneTimeProductNotification) {
      const n = event.oneTimeProductNotification;
      const token = String(n.purchaseToken||"");
      const productId = String(n.sku||"");

      // Refresh purchase state from Google Play Developer API.
      if (token && productId) {
        try {
          const play = await fetchPlayProductPurchase(productId,token);
          await pool.query(
            `update play_purchases
                set purchase_state=$1,updated_at=now()
              where purchase_token=$2`,
            [
              play.purchaseState===0 ? "PURCHASED" :
              play.purchaseState===2 ? "PENDING" : "CANCELED",
              token
            ]
          );
        } catch(e) {
          console.error("RTDN product refresh failed",e?.response?.data||e);
        }
      }
    }
    return res.status(204).end();
  } catch(e) {
    console.error("RTDN processing failed",e);
    // Pub/Sub can retry on non-2xx.
    return res.status(500).json({error:"rtdn_processing_failed"});
  }
});


app.post("/v1/account/deletion-request", async (req,res)=>{
  const email = normalizeEmail(req.body.email || "");
  if (!validEmail(email)) {
    // Keep external behavior generic to reduce account enumeration.
    return genericDeletionRequestResponse(res);
  }

  let member;
  try {
    const q = await pool.query(`select id,email from members where email=$1`,[email]);
    member = q.rows[0];
  } catch(e) {
    console.error("Deletion lookup failed",e);
    return genericDeletionRequestResponse(res);
  }

  if (!member) {
    // Same response for absent accounts.
    return genericDeletionRequestResponse(res);
  }

  const rawToken = base64UrlRandom(32);
  const tokenHash = sha256Hex(rawToken);

  try {
    // Revoke old unused deletion tokens for this member.
    await pool.query(
      `update account_delete_tokens
          set used_at=coalesce(used_at,now())
        where member_id=$1 and used_at is null`,
      [member.id]
    );

    await pool.query(
      `insert into account_delete_tokens(
         member_id,token_hash,expires_at,request_ip_hash
       ) values(
         $1,$2,now()+($3::text||' minutes')::interval,$4
       )`,
      [
        member.id,
        tokenHash,
        String(ACCOUNT_DELETE_TTL_MINUTES),
        sha256Hex(req.ip || "")
      ]
    );

    await sendAccountDeletionEmail(member.email, rawToken);
  } catch(e) {
    console.error("Deletion email setup/send failed",e);
    // Never expose whether the account exists or email sending failed.
  }

  return genericDeletionRequestResponse(res);
});

app.get("/v1/account/deletion-confirm", async (req,res)=>{
  const rawToken = String(req.query.token || "");
  if (rawToken.length < 32) {
    return res.status(400).json({error:"invalid_or_expired_token"});
  }
  const tokenHash = sha256Hex(rawToken);

  const client = await pool.connect();
  try {
    await client.query("begin");

    const q = await client.query(
      `select id,member_id,expires_at,used_at
         from account_delete_tokens
        where token_hash=$1
        for update`,
      [tokenHash]
    );
    const row = q.rows[0];

    if (!row || row.used_at || new Date(row.expires_at).getTime() <= Date.now()) {
      await client.query("rollback");
      return res.status(400).json({error:"invalid_or_expired_token"});
    }

    await client.query(
      `update account_delete_tokens set used_at=now() where id=$1`,
      [row.id]
    );

    await performAccountDeletion(client,row.member_id);

    await client.query("commit");
    return res.json({ok:true,deleted:true});
  } catch(e) {
    await client.query("rollback").catch(()=>{});
    console.error("Deletion confirm failed",e);
    return res.status(500).json({error:"account_delete_failed"});
  } finally {
    client.release();
  }
});


function assertProductionEnvironment() {
  if (process.env.NODE_ENV !== "production") return;
  const problems = [];
  const required = {
    DATABASE_URL: process.env.DATABASE_URL,
    JWT_SECRET: process.env.JWT_SECRET,
    GOOGLE_WEB_CLIENT_ID: process.env.GOOGLE_WEB_CLIENT_ID,
    GOOGLE_SERVICE_ACCOUNT_JSON: process.env.GOOGLE_SERVICE_ACCOUNT_JSON,
    ACCOUNT_DELETE_CONFIRM_BASE_URL: process.env.ACCOUNT_DELETE_CONFIRM_BASE_URL,
    SMTP_HOST: process.env.SMTP_HOST,
    SMTP_USER: process.env.SMTP_USER,
    SMTP_PASS: process.env.SMTP_PASS,
    SMTP_FROM: process.env.SMTP_FROM
  };
  for (const [k,v] of Object.entries(required)) {
    if (!String(v || "").trim()) problems.push(`${k}_missing`);
  }
  if (String(process.env.JWT_SECRET || "").length < 32) problems.push("JWT_SECRET_too_short");
  if (!/^https:\/\//i.test(String(process.env.ACCOUNT_DELETE_CONFIRM_BASE_URL || ""))) {
    problems.push("ACCOUNT_DELETE_CONFIRM_BASE_URL_must_be_https");
  }
  if (problems.length) throw new Error("production_environment_invalid:" + problems.join(","));
}

assertProductionEnvironment();

const port = Number(process.env.PORT || 8080);
app.listen(port, ()=>console.log(`Meihua backend V13.01 listening on :${port}`));
