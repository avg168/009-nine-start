# V12.94｜Google Play RTDN 設定

1. 在 Google Cloud 建立 Pub/Sub topic。
2. 將 Google Play Developer Notifications 用的 service account / publisher 權限設定完成。
3. 在 Play Console 的 Monetize / Monetization setup 中設定 Real-time developer notifications topic。
4. 建立 Pub/Sub push subscription。
5. Push endpoint 指向：
   https://YOUR_BACKEND.example/v1/google/rtdn
6. 使用 Play Console 的 test notification 測試。
7. 確認後端 rtdn_messages 表新增 messageId。
8. 同一 messageId 再送一次時，不重複處理。

V12.94 處理：
- testNotification
- oneTimeProductNotification
- voidedPurchaseNotification
- messageId 去重
- packageName 驗證
- one-time product 收到通知後再查 Google Play Developer API
- full voided purchase 點數追回
- partial quantity refund 暫標 PARTIAL_REFUND_REVIEW，避免錯扣

重要：
RTDN 不是完整交易資料來源。
收到通知後，仍應依事件類型查 Google Play Developer API。
