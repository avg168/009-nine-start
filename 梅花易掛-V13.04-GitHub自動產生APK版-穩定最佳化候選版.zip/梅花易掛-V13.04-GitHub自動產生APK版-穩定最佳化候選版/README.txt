梅花易掛 Android V12.86｜實機耐用版

核心內容：
1. 內建 V12.86 HTML（由 V12.80 正式候選版升版，64卦/384爻/384小象資料不變）
2. JavaScript + DOM Storage
3. AndroidPoints SharedPreferences 點數橋接
4. WebView saveState / restoreState，旋轉或 Activity 重建後恢復瀏覽狀態
5. 外部網址交由系統瀏覽器/應用程式處理，不讓外部網頁留在帶有 JS Bridge 的 WebView
6. 返回鍵先關閉「我的卦象 / 我的點數」，其次使用 WebView 歷史，最後離開 App
7. 回到前景時重新執行功能、產品與發布稽核
8. 關閉 universal file URL access，縮小 WebView 權限面

Android Studio：
File > Open > 選擇本專案資料夾
等待 Gradle Sync 完成
Build > Build Bundle(s) / APK(s) > Build APK(s)

目前設定：
applicationId: global.meihua.yigua
minSdk: 26
targetSdk: 35
versionCode: 1284
versionName: 12.85


V12.86 實機橋接補強：
- AndroidClipboard.copyText：原生複製
- AndroidBridge.shareText：原生分享 Intent
- AndroidBridge.saveTextFile：Android 10+ 儲存到 Downloads/梅花易掛；Android 8-9 使用 App 專屬下載資料夾
- 保留 AndroidPoints SharedPreferences 點數保存

V12.86 實機流程總驗證補強：
- WebView renderer 被系統回收/崩潰時，自動重建並回到內建首頁，避免白畫面
- 頁面載入完成後重新執行 MHFunctionAudit / MHProductionAudit / MHReleaseAudit
- AndroidBridge 新增 ping() 與 getAppVersion() 供 HTML 稽核確認原生橋接在線
- Android 10+ 下載若中途失敗，刪除未完成 MediaStore 項目，避免殘留空白檔
- 64卦、384爻、384小象原典資料不變


V12.86 release preparation:
- compileSdk/targetSdk 36
- AGP 8.13.2
- adaptive + monochrome launcher icon
- Android 12+ splash screen resources
- conditional release signing via keystore.properties
- RELEASE-CHECKLIST.txt added
