# 梅花易掛｜V12.98 外部帳號刪除入口

流程：
1. `index.html` 輸入 Email。
2. POST `/v1/account/deletion-request`。
3. 後端不透露 Email 是否存在；一律回泛化成功訊息。
4. 若會員存在，產生 32-byte crypto random token。
5. DB 只保存 SHA-256 token hash，不保存原始 token。
6. Token 預設 30 分鐘到期，且只能使用一次。
7. SMTP 寄出 HTTPS 確認連結。
8. 使用者開啟 `confirm.html?token=...`。
9. GET `/v1/account/deletion-confirm?token=...`。
10. 後端 transaction 執行帳號刪除。
11. 雲端卦象刪除；交易／點數稽核資料解除 member 關聯。

正式部署前：
- `index.html` 與 `confirm.html` 的 `API_BASE` 填正式 HTTPS API。
- `ACCOUNT_DELETE_CONFIRM_BASE_URL` 應指向公開 `confirm.html` 網址，例如：
  https://www.example.com/account-delete/confirm.html
- 設定 SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS / SMTP_FROM。
- 不可把 SMTP 密碼放進 Android APK 或前端 JavaScript。
- 建議在 reverse proxy / WAF 加上 IP 與 Email rate limiting / CAPTCHA。
