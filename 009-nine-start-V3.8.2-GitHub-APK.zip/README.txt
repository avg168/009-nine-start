009 九人啟動 V3.8.1｜APK 編譯前工程整理版

【本版重點】
1. 修正 Android 13～16 新返回 API 與 Manifest 設定互相矛盾的問題。
2. Manifest 改為 android:enableOnBackInvokedCallback="true"。
3. Android 16 / API 36 edge-to-edge 保留 system bars inset 處理。
4. WebView 增加 mixed-content 禁止、主頁載入失敗提示、外部網址保護。
5. AndroidBridge 分享增加空字串與例外保護。
6. onDestroy 會移除 JavaScript Bridge、停止載入並釋放 WebView。
7. V3.8.1 改用 localStorage 主鍵 009v38，會自動向下讀取 009v37 等舊資料。
8. Gradle Wrapper properties 已指定 Gradle 8.11.1；因目前環境無法下載官方 wrapper jar，所以未偽造 gradle-wrapper.jar。

【版本】
Package: global.a009.ninestart
versionCode: 381
versionName: 3.8.1
minSdk: 24
targetSdk: 36
compileSdk: 36
AGP: 8.9.1
Gradle requirement: 8.11.1+
Java: 17

【Android Studio】
1. 解壓 ZIP。
2. Android Studio → Open → 選整個 009-nine-start-v3.8.1-build-ready 資料夾。
3. SDK Manager 確認 Android 16 / API 36 已安裝。
4. 讓 Android Studio 執行 Gradle Sync。
5. 若提示下載 Gradle，使用 8.11.1。
6. Build → Build Bundle(s) / APK(s) → Build APK(s)。

【真機必測】
- 首次啟動畫面與新手導覽
- 五個底部導航
- 第一章7關與尊重式退出
- 3/6/9寶箱與EXP
- 第二章7個陪伴任務
- 第三章4個共創任務
- Android返回手勢/返回鍵
- 原生分享面板
- 鍵盤彈出後表單是否被遮住
- Android 14/15/16 system bars
- 關閉APP再開啟後資料是否保留

【尚未正式接入】
- Android系統通知
- 真AI服務
- tw.009.global SSO / 後端同步
- 正式活動資料與預約
- Google Play簽章/AAB
